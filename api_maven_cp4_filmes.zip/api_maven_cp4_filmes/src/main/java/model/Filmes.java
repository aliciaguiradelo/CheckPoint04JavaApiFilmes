package model;
import java.util.HashMap;

public class Filmes {
	//Atributos da classe Filmes
	//Os nomes dos atributos devem ser iguais aos nomes das variáveis que estão na API
	//Só preciso declarar os atributos que eu vou usar, não importa se tiver outros na Api. 
	//Nesse caso eu não vou usar o atributo foto 
	//A chave da API vira um atributo aqui
	private int id;
	private String nome;
	private String sinopse;
	//Vou guardar os comentários dentro de outro hashmap
	private HashMap <Integer, Comentarios> listaComentarios = new HashMap<Integer, Comentarios>();
	
	//Getters and Setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSinopse() {
		return sinopse;
	}
	public void setSinopse(String sinopse) {
		this.sinopse = sinopse;
	}
	public HashMap<Integer, Comentarios> getComentarios() {
		return listaComentarios;
	}
	//Criando os métodos para CRUD dos comentários
	int idComentario;
	
	public void adicionarComentario(String usuario, String comment) {
		Comentarios comentario = new Comentarios();
		int id;
		int maximo = 0;
		if(listaComentarios.size() == 0) {
			id = 1;
		}else {
			for(Integer i: listaComentarios.keySet()) {
				if(i > maximo) {
					maximo = i;
				}
			}			id = maximo + 1;
		}
		comentario.setId(id);
		comentario.setComentario(comment);
		comentario.setUsuario(usuario);
		//Adicionando o objeto comentário dentro do hasmap
		listaComentarios.put(id, comentario);	
	}
	
	public void editarComentario(String comment, String usuario) {
		if (listaComentarios.containsKey(id)) {
			Comentarios comentario = listaComentarios.get(id);
			comentario.setComentario(comment);
			comentario.setUsuario(usuario);
			listaComentarios.put(id, comentario);
	
			
     	   System.out.printf("Comentario editado com sucesso!");
     	   
        }
        else {
        	System.out.printf("Comentario não encontrado!");
        }
	}
	
	public void excluirComentario(Integer id) {
		if (listaComentarios.containsKey(id)) {
			listaComentarios.remove(id);
     	   System.out.printf("Comentario excluído com sucesso!");
        }
        else {
     	   System.out.printf("Comentario não encontrado!");
        }
	}
	
	public void exibirComentarios() {
		listaComentarios.forEach((chave, valor) -> {
            System.out.printf("\nID: " + chave + 
            				  " - Comentário: " + valor.getComentario() + 
            				  " - Usuário : " + valor.getUsuario());
          });
	}
	
	
	
	
}