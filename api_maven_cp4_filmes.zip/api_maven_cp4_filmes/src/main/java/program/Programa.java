package program;
import model.Filmes;
import service.FilmeService;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;
import org.apache.http.client.ClientProtocolException;

public class Programa {

	public static void main(String[] args) throws ClientProtocolException, IOException {

		Scanner ler = new Scanner(System.in);

		int opcao = 0;
		int idFilme;
		int idComentario;
		String nome = null;
		String comentario = null;

		FilmeService fs = new FilmeService();
		HashMap<Integer, Filmes> filmes = fs.getListaFilmes();
		
		while(true) {
			System.out.printf("\n\n\n======>      BEM VINDO AO CINEMARK      <======\n\n");
			System.out.printf("\n         Lista dos nossos filmes       \n\n");
			for (Integer filme : filmes.keySet()) {
				System.out.println(filmes.get(filme).getId() + " - " + filmes.get(filme).getNome());
			}
			System.out.printf("\n\n\nEscolha uma opção:\n");
			System.out.printf("\n1 - Ver detalhes do filme \n" +
                              "2 - Adicionar um comentário \n" +
                              "3 - Editar um comentário \n" +
                              "4 - Excluir um comentário \n" +
                              "5 - Sair\n\n");

			System.out.printf("Digite a opção desejada: ");
			opcao = ler.nextInt();
			
			if (opcao == 1) {

				System.out.printf("Digite o ID do filme: ");
				idFilme = ler.nextInt();
				
				for(Integer filme: filmes.keySet()) {
					if(idFilme == filmes.get(filme).getId()) {
						System.out.printf("\nTítulo  : " + filmes.get(filme).getNome() +
										  "\nSinopse  : " + filmes.get(filme).getSinopse());
						
						if(filmes.get(filme).getComentarios().size() != 0) {
							System.out.printf("\n\nComentários: \n");
							filmes.get(filme).exibirComentarios();
						}
						else {
							System.out.printf("\nNenhum comentário foi realizado neste título\n\n");
						} 
						break;
					}
				}
			}
			else if(opcao == 2) {
				System.out.printf("Digite o ID do filme: ");
				idFilme = ler.nextInt();
				System.out.printf("Digite o seu nome: ");
				nome = ler.next();
				System.out.printf("Digite o seu comentário: ");
				comentario = ler.next();

				for(Integer filme: filmes.keySet()) {
					if(idFilme == filmes.get(filme).getId()) {
						filmes.get(filme).adicionarComentario(nome, comentario);
						System.out.printf("\nComentário adicionado com sucesso!\n");
						break;
					}
				}
			}
			else if (opcao==3) {
				System.out.printf("Digite o ID do filme: ");
				idFilme = ler.nextInt();
				
				for(Integer filme: filmes.keySet()) {
					if(idFilme == filmes.get(filme).getId()) {
						
						if(filmes.get(filme).getComentarios() != null) {
							System.out.printf("\nComentários: ");
							filmes.get(filme).exibirComentarios();
							
							System.out.printf("\nDigite o ID do comentário que deseja editar: ");
							idComentario = ler.nextInt();
							
							System.out.printf("Digite o seu nome: ");
							nome = ler.next();
							System.out.printf("Digite o seu comentário: ");
							comentario = ler.next();
							
							filmes.get(filme).editarComentario(nome, comentario);
							
						}else {
							System.out.printf("\nNenhum comentário foi realizado neste título");
						}
						break;
					}
				}
				
			}
			else if(opcao == 4) {
				System.out.printf("Digite o ID do filme: ");
				idFilme = ler.nextInt();
				
				for(Integer filme: filmes.keySet()) {
					if(idFilme == filmes.get(filme).getId()) {
						
						if(filmes.get(filme).getComentarios() != null) {
							System.out.printf("\nComentários: ");
							filmes.get(filme).exibirComentarios();
							
							System.out.printf("\nDigite o ID do comentário que gostaria de excluir: ");
							idComentario = ler.nextInt();
							
							filmes.get(filme).excluirComentario(idComentario);
						}else {
							System.out.printf("\nNenhum comentário foi realizado neste título!");
						}
						break;
					}
				}
			}
			else {
				System.out.println("O CINEMARK agradece a sua preferência !");
				break;
			}
		}

		ler.close();
	}

}
