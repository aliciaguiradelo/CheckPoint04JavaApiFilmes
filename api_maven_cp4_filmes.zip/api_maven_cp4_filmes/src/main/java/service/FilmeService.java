package service;
import java.io.IOException;
//Biblioteca que possui métodos para utlizar HashMap
import java.util.HashMap;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
//Bibliotecas para podermos trabalhar com json (dicionário de dados)
import org.json.JSONArray;
import org.json.JSONObject;
//Importando classe Filmes
import model.Filmes;

public class FilmeService {
	//Declarando o método getListaFilmes() que vai armazenar os dados vindos da api e retornar o hashmap listaFilmes
	public HashMap<Integer, Filmes> getListaFilmes() throws ClientProtocolException, IOException {

		//Instanciando um HashMap chamado listaFilmes. Ele vai ter na chave um tipo de número inteiro e no valor
		//vai receber um objeto do tipo Filmes
		HashMap<Integer, Filmes> listaFilmes = new HashMap<Integer, Filmes>();

		//Criando um objeto que vai fazer uma request na api 
		HttpGet request = new HttpGet("https://sujeitoprogramador.com/r-api/?api=filmes");

		try (CloseableHttpClient httpClient = HttpClientBuilder.create().disableRedirectHandling().build();
				CloseableHttpResponse response = httpClient.execute(request)) {

			HttpEntity entity = response.getEntity();

			//Verificando se a api tá retornando algo nulo
			if (entity != null) {

				String result = EntityUtils.toString(entity);

				JSONArray payload = new JSONArray(result);
				

				for (int i = 0; i < payload.length(); i++) {
					
					JSONObject requiredMovie = payload.getJSONObject(i);
					
					//Instanciando o objeto filmes e setando os atributos dele com os dados que a API trouxe pra mim
					Filmes filmes = new Filmes();
					
					filmes.setId(requiredMovie.getInt("id"));
					filmes.setNome(requiredMovie.getString("nome"));
					filmes.setSinopse(requiredMovie.getString("sinopse"));
					
					//No hashmap o método para adicionar na collection é put. No ArrayList e no hashset é add()
					//Coloquei i + 1 porque a contagem começa no 0 
					listaFilmes.put(i + 1, filmes);
				
				}
			}

			return listaFilmes;
		}

	}

}